package hotelsystem;
import java.util.ArrayList;
import static hotelsystem.Hotel.input; //Import same Scanner form the main class 
//You can import like this PackageName.ClassName.VariableName

//***KitchenService Class is Subclass of HotelService Class***
// 3 Main Methods:
// 1- KitchenServices
// 2- Dishes
// 3- Drinks



public class KitchenService extends HotelService{
    
    static ArrayList<KitchenService> DrinkList = new ArrayList<>(); 
    static ArrayList<KitchenService> FoodList = new ArrayList<>();
    static final String KitchenMenu = "====================================\n" +
        "|        choose selection:         |\n" +
        "|        1.Dishes                  |\n" +
        "|        2.Drink                   |\n" +
        "|        3.Back to main menu       |\n" +
        "====================================\n";
    static final String MyDishesMenu = "====================================\n" +
            "|choose selection:                 |\n" +
            "| 1.Pizza            price: 55 SAR |\n" +
            "| 2.Pasta            price: 30 SAR |\n" +
            "| 3.Burger           price: 26 SAR |\n" +
            "| 4.Back to main menu              |\n" +
            "====================================\n";
    static final String MyDrinksMenu = "====================================\n" +
            "|choose selection:                 |\n" +
            "| 1.Water            price: 2 SAR  |\n" +
            "| 2.Orange Juice     price: 11 SAR |\n" +
            "| 3.Coffee           price: 17 SAR |\n" +
            "| 4.Back to main menu              |\n" +
            "====================================\n";

    //CONSTRUCTORS:
    public KitchenService(int BookingID, String ItemName, double ItemPrice){
        super(BookingID,ItemName,ItemPrice);
    }
    
    //Main Kitchen Services
    public static void KitchenServices(){
        //This Method is to display Guest's Mneu and make him/her choose until they choose Back.
        boolean found = false;
        while(!found){
            System.out.print("| Enter Your Booking ID To Access Food and Drinks Services: ");
            int Bookid = input.nextInt();
            for(int i=0; i<BookingRoom.RoomList.size();i++){
                if(BookingRoom.RoomList.get(i).getBookingid()==Bookid){
                    found=true;         
                }
            }

            if(found){
                System.out.print("\n====================================\n"
                                +"= Welcome To Food and Drinks Services =\n");
                int kind;
                do{   
                    System.out.println(KitchenMenu);
                    System.out.print("| Your choice: ");
                    kind = input.nextInt();
                    switch (kind){
                        case 1:
                            Dishes(Bookid);
                            break;
                        case 2:
                            Drinks(Bookid);
                            break;
                        case 3:
                            break;
                        default:
                            System.out.println("!! ERROR: This Option Invalid !! ");
                            break;
                    }
                }while(kind!=3);
                displayFoodServices();
                displayDrinksServices();

            }
            else
                System.out.println("!! ERROR: No Booking Found With Provided ID !!");

        }
    }
    
    //Dishes Method
    private static void Dishes (int id){
        int ChoseDish;
        System.out.print("\n====================================\n"
                          +"=========== Drinks Menu ===========\n");
        System.out.println(MyDishesMenu);
            do {               
                System.out.print("| Your choice: ");
                ChoseDish = input.nextInt();
                switch (ChoseDish) {
                    case 1:
                        FoodList.add(new KitchenService(id,"Pizza", 55));
                        System.out.println("***** Item Added Successfully *****");
                        break;
                    case 2:
                        FoodList.add(new KitchenService(id,"Pasta",  30));
                        System.out.println("***** Item Added Successfully *****");
                        break;
                    case 3:
                        FoodList.add(new KitchenService(id,"Burger ", 26));
                        System.out.println("***** Item Added Successfully *****");
                        break;
                    case 4:
                        break;
                    default:
                        System.out.println("!! ERROR: This Option Invalid !! ");
                        break;
                    }
            } while(ChoseDish != 4);
    }
    
    //Drinks Method
    private static void Drinks (int id){
        int ChoseDrink;
        System.out.print("\n====================================\n"
                          +"=========== Drinks Menu ===========\n");
        System.out.println(MyDrinksMenu);
        do {
            
            System.out.print("| Your choice: ");
            ChoseDrink = input.nextInt();
            switch (ChoseDrink) {
                case 1:
                    DrinkList.add(new KitchenService(id,"Water", 2));
                    System.out.println("***** Item Added Successfully *****");
                    break;
                case 2:
                    DrinkList.add(new KitchenService(id,"Orange Juice", 11));
                    System.out.println("***** Item Added Successfully *****");
                    break;
                case 3:
                    DrinkList.add(new KitchenService(id,"Coffee", 17));
                    System.out.println("***** Item Added Successfully *****");
                    break;
                case 4:
                    break;
                default:
                    System.out.println("!! ERROR: This Option Invalid !! ");
                    break;
                }
            } while (ChoseDrink != 4);
    }
    
    public static void displayFoodServices(){
       
       for(int i = 0; i< FoodList.size();i++){
            KitchenService x = FoodList.get(i);
            System.out.println("*** You choose: "+x.getItem()+", and price "+x.getPrice() +" SAR ***" );
        }
   }
    
   public static void displayDrinksServices(){
       
       for(int i = 0; i< DrinkList.size();i++){
            KitchenService x = DrinkList.get(i);
            System.out.println("*** You choose: "+x.getItem()+", and price "+x.getPrice() +" SAR ***" );
        }
   }
}
