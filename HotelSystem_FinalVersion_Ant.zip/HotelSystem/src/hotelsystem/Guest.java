package hotelsystem;
import java.util.ArrayList;
import static hotelsystem.Hotel.input; //Import same Scanner form the main class 
//You can import like this PackageName.ClassName.VariableName


//***Guest Class is Subclass of User Class***
// 2 Main Methods:
// 1- Search for a Guest
// 2- Delete a Guest




//START of Guest Class
public class Guest extends User{
    
    //Declare variables needed
    private final String UserEmail;
    static ArrayList<Guest> GuestList = new ArrayList<>();
        
    //CONSTRUCTORS
    public Guest(String UserName, int UserID, String UserEmail,String UserPhoneNumber) {	
	super(UserName, UserID, UserPhoneNumber);
        this.UserEmail = UserEmail;
    }

    //GETTERS
    //GET Guest Email
    public String getUserEmail() {
        return UserEmail;
    }

    
    //Delete Guest information
    public static void DeleteGuest(int guest_id) {//START of DeleteGuest
        
        for(int i = 0; i < GuestList.size();i++){
           if(GuestList.get(i).getUserID() == guest_id)
            {
                GuestList.remove(GuestList.get(i));
              
            }
        }
        
        if(!BookingRoom.RoomList.isEmpty() || !!KitchenService.FoodList.isEmpty() || !KitchenService.DrinkList.isEmpty() || !!SpaServices.SpaList.isEmpty() || !GYM.GymList.isEmpty())               
        {
            //Remove All room reserved by guest
            for(int r=0;r<BookingRoom.RoomList.size();r++){
                if(BookingRoom.RoomList.get(r).getBookingid() == guest_id)
                    BookingRoom.RoomList.remove(BookingRoom.RoomList.get(r));  
                }
               
            //Remove All Food or Drink items reserved by guest
            for(int f=0;f<KitchenService.FoodList.size();f++){
                if(KitchenService.FoodList.get(f).getBookingid() == guest_id)
                    KitchenService.FoodList.remove(KitchenService.FoodList.get(f));  
            }
               
            for(int d=0;d<KitchenService.DrinkList.size();d++){
                if(KitchenService.DrinkList.get(d).getBookingid() == guest_id)
                    KitchenService.DrinkList.remove(KitchenService.DrinkList.get(d));  
            }
            //Remove All Spa Services reserved by guest
            for(int s=0;s<SpaServices.SpaList.size();s++){
                if(SpaServices.SpaList.get(s).getBookingid() == guest_id)
                    SpaServices.SpaList.remove(SpaServices.SpaList.get(s));  
            }
            //Remove All GYM Services reserved by guest
            for(int g=0;g<GYM.GymList.size();g++){
                if(GYM.GymList.get(g).getBookingid() == guest_id)
                    GYM.GymList.remove(GYM.GymList.get(g));  
            }
   
        }
        System.out.println("********* The Booking Information Deleted Successfuly ********* ");

        
                
	
    }//END of DeleteGuest
	
 
   //Search for Guest
    public static void SearchGuest() { //START of SearchGuest
        String ans;
        boolean found = false;
        int GuestID;
        if(!GuestList.isEmpty()){
            while(!found){ //Do While not found 
                    System.out.print("| Enter Your Booking ID To Delete (0 to go back): ");
                    GuestID = input.nextInt();
                    if(GuestID==0){
                        break;   
                    }
                    for(int g = 0; g < GuestList.size();g++){
                        if(GuestList.get(g).getUserID() == GuestID){
                            System.out.println("====== Booking Information found: ======");
                            System.out.println("Booking ID: "+GuestList.get(g).getUserID());
                            System.out.println("Guest Name: "+GuestList.get(g).getUserName());
                            System.out.println("Guest Email: "+GuestList.get(g).getUserEmail());
                            System.out.println("Guest Phone Number: "+GuestList.get(g).getUserPhoneNumber());
                            System.out.println("==========================================");
                            System.out.println("Do you want to delete this Information? ");
                            System.out.println("%% WARRNING: All Your Previous Reservations Will be Deleted %%");
                            System.out.print("| Confirm (Y/N)? : ");
                            ans = input.next();
                            found = true;
                            if(ans.equalsIgnoreCase("Y")){
                                DeleteGuest(GuestID);
                            }
                            else if(ans.equalsIgnoreCase("N")){
                                break;
                            }
                        }

                    }
                    if (!found) {
                        System.out.println("!! ERROR: No Guest with same ID provided !!");
                    }
            }

        }
        else
            System.out.println("!! ERROR: No Reservations Yet !!");
    }//END of SearchGuest
        

}//END of Guest Class