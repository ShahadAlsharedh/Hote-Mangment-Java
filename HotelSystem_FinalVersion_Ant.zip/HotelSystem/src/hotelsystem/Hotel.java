package hotelsystem;
import java.util.Scanner;

//***Hotel Class Only include the call of other clasess***
public class Hotel {//START of Hotel Class
    
    //Declare Variables 
    static Scanner input = new Scanner(System.in); //Scanner to take input from user (use the same Scanner for all the classese)
    static final String MainMenu= //Menu For the user
            "| MainMenu                            |\n"+
            "========================================\n"+
            "| Are You:                             |\n"+
            "|        1-Admin                       |\n"+
            "|        2-Guest                       |\n"+
            "|        3-Quit                        |\n"+
            "========================================\n";


    //Main of the program    
    public static void main(String[] args){
        
        //Add 2 Admins to the system
        Admin.AdminList.add(new Admin("Mohammed ",2222, "m22m", "0509830099", 3000, 30));
        Admin.AdminList.add(new Admin("Sara ",3333, "s22s", "0509830888", 5000, 30));
        
        //Declare Variables
        int main_choice; //To take user choice either admin or guest
        
        //Do Untill user Click 3 (Quit)
        do{
                System.out.print(MainMenu ); //Print Menu for the user
                System.out.print("| Your choice: " ); 
                main_choice = input.nextInt(); //Take input from user
                switch(main_choice){ //START of user choice Switch
                    case 1: //Admin case:
                        Admin.AdminSwitchChoice();
                        break; //Break admin case                 
                    case 2://Guest Case
                        //HERE is the code of the guest system
                        HotelService.Services();
                        break; //Break Guest case  
                    case 3:
                        System.out.print("Thank you for using Hotel System...Have a nice day :)");
                        break; 
                    default:
                        System.out.println("!! ERROR: This Option Invalid !! ");
                        break;
                }//END of Main Switch.
                
        }while(main_choice!=3);
    }//END of Main Function

}//END of Hotel Class