package hotelsystem;
import java.util.ArrayList;
import java.util.regex.Pattern;
import static hotelsystem.Hotel.input; //Import same Scanner form the main class 
//You can import like this PackageName.ClassName.VariableName


//***BookingRoom Class is Subclass of HotelService Class***
// 2 Main Methods:
// 1- Add New Booking
// 2- Display Booking


public class BookingRoom extends HotelService{
    
    //Declare Variables:
    private String RoomNum;
    private String guestname;
    private String guestEmail;
    private String guestPhone;
    private static int aval_rooms;
    public String RoomType;
    private String BookingDate;
    private String BookingTime;
    private static int MAXROOMS = 20;
    static String rooms_reserved="";
    static ArrayList<BookingRoom> RoomList = new ArrayList<>();
    static final String RoomsMenu=
            "| Rooms Avaliable                       |\n"+
            "========================================\n"+
            "| Choose a room:                       |\n"+
            "| 1-King room          price: 350 SR   |\n"+
            "| 2-Double room        price: 250 SR   |\n"+
            "| 3-Single room        price: 150 SR   |\n"+
            "| 4-Back to main menu                  |\n"+
            "========================================\n";


    
    //CONSTRUCTORS:
    public BookingRoom(int Bookingid,String RoomNum,double price){
        super(Bookingid,RoomNum,price);
    }
    public BookingRoom(int Bookingid,String guestname ,String guestEmail,String guestPhoneNumber,String RoomNum, String BookingDate, String BookingTime, String RoomType,double price){
        super(Bookingid,RoomType,price);
        this.guestname = guestname;
        this.guestEmail = guestEmail;
        this.RoomNum = RoomNum;
        this.BookingDate = BookingDate;
        this.BookingTime = BookingTime;
        this.RoomType = RoomType;
        this.guestPhone = guestPhoneNumber;
    }

    
    //SETTERS:
    public void setRoomNum(String RoomNum){
        this.RoomNum = RoomNum;
    }
    
    //GETTERS:
    
    //GET Room Type
    public String getRoomType() {
        return RoomType;
    }

    //GET Booking date
    public String getBookingDate() {
        return BookingDate;
    }
    //GET Booking time
    public String getBookingTime() {
        return BookingTime;
    }
    //GET guest name
    public String getGuestname() {
        return guestname;
    }
    //GET guest email
    public String getGuestEmail() {
        return guestEmail;
    }
    //GET guest phone
    public String getGuestPhone() {
        return guestPhone;
    }
    
    
    //Display Booking info Method:
    public static void CheckBooking(){//START of CheckBooking
        boolean found = false;
        int book_ID;
        int numberOfrooms =0;
        String roomsType="";
        int index=0;
        while(!found){
            if (!RoomList.isEmpty()){
                System.out.print("| Enter Booking ID To Show Booking Information (0 to go back):  ");
                book_ID = input.nextInt();
                if(book_ID==0){
                    break;   
                }
                for(int i = 0; i < RoomList.size();i++){
                    if (RoomList.get(i).getBookingid() == book_ID){
                        index=i;
                        numberOfrooms+=1;
                        roomsType+=RoomList.get(i).getRoomType()+"\n";
                        found=true;
                    }

                }
                if (found){
                        System.out.println("====== Booking Information found: ======");
                        System.out.println("Booking ID: "+RoomList.get(index).getBookingid());
                        System.out.println("Guest Name: "+RoomList.get(index).getGuestname());
                        System.out.println("Guest Email: "+RoomList.get(index).getGuestEmail());
                        System.out.println("Guest Phone Number: "+RoomList.get(index).getGuestPhone());
                        System.out.println("Number of Rooms: "+numberOfrooms);
                        System.out.println("Types of Rooms: ");
                        System.out.print(roomsType);
                        System.out.println("Room Date: "+RoomList.get(index).getBookingDate());
                        System.out.println("Room Time: "+RoomList.get(index).getBookingTime());
                        System.out.println("==========================================");
                        found = true;
                    
                }
                else
                    System.out.println("!! ERROR: No Booking Found With Provided ID !!");
            }
            else
                System.out.println("!! ERROR: No Reservations Yet !!");


        }
    }//END of CheckBooking

    
    //Add booking method
    public static void AddBooking(){//START of AddBooking
        System.out.println("============ New Reseration ============");
        if(aval_rooms <= MAXROOMS){
            int id = (int)Math.floor(Math.random()*(1000-1+1)+1);
            System.out.println("==== Please Enter Booking information ====");
            
            //Take guest name
            System.out.print("| Enter Guest's or Booking Name: ");
            String BookingName = input.next();
            
            //Take guest email (Apply regular expression here)
            System.out.print("| Enter Guest's Email: ");
            String BookingEmail = input.next();
            while(!isValid(BookingEmail)){
                System.out.println("!! ERROR: Workin hours is Invalid !!");
                System.out.print("| Please Enter Again: ");
                BookingEmail = input.next();
            }
            
            //Take guest phone number (Must be 10 digit and start with 05)
            System.out.print("| Enter Guest's Phone Number: ");
            String ReservoirPhone = input.next();        
            while(!chekcPhone(ReservoirPhone)|| ReservoirPhone.length() != 10 || !(ReservoirPhone.startsWith("05"))){
                System.out.println("!! ERROR: This Phone number Invalid !!");
                System.out.print("| Please enter again: ");
                ReservoirPhone = input.next();
            }

            //Take booking date (Apply regular expression here)
            System.out.print("| Enter Date of Booking dd/MM/yyyy : ");
            String ReservationDate = input.next();     
            while(!checkDate(ReservationDate)){
                System.out.println("!! ERROR: This Date is in Wrong Format or Old !!");
                System.out.print("| Please enter again: ");
                ReservationDate = input.next();
            }
            
            //Take booking time (Apply regular expression here)
            System.out.print("| Enter Time of Booking HH:mm (24 hours): ");
            String ReservationTime= input.next();      
            while(!checkTime(ReservationTime)){
                System.out.println("!! ERROR: This Time is in Wrong Format !!");
                System.out.print("| Please enter again: ");
                ReservationTime = input.next();
            }
            
            //Take guest rooms (book more than room at once)
            String room_numbers = "";
            int room_ch;
            int room_num;
            System.out.println("Choose Room Type:");
            System.out.print(RoomsMenu);
            do{//Do until guest choose 4
                System.out.print("| Your choice: ");
                room_ch= input.nextInt();
                switch(room_ch){
                    case 1://King room case
                        //Create new booking and assign room number to it
                        BookingRoom NewRoomBooking1 = new BookingRoom(id,BookingName,BookingEmail,ReservoirPhone,room_numbers,ReservationDate,ReservationTime,"King Room",350.0);
                        RoomList.add(NewRoomBooking1);
                        while(true){
                            room_num = (int)Math.floor(Math.random()*(MAXROOMS-1+1)+1);
                            if(!rooms_reserved.contains(""+room_num+"")){
                                room_numbers+=" "+room_num+" ";
                                break;
                            }     
                        }
                        System.out.println("***** Room Added Successfully *****");
                        aval_rooms+=1; //increament the avaliable rooms so when the hotel is full no guest can book
                        break;
                    
                    case 2://Double room case
                        //Create new booking and assign room number to it
                        BookingRoom NewRoomBooking2 = new BookingRoom(id,BookingName,BookingEmail,ReservoirPhone,room_numbers,ReservationDate,ReservationTime,"Double Room",250.0);
                        RoomList.add(NewRoomBooking2);
                        while(true){
                            room_num = (int)Math.floor(Math.random()*(MAXROOMS-1+1)+1);
                            if(!rooms_reserved.contains(""+room_num+"")){
                                room_numbers+=" "+room_num+" ";
                                break;                 
                            }     
                        }
                        System.out.println("***** Room Added Successfully *****");
                        aval_rooms+=1; //increament the avaliable rooms so when the hotel is full no guest can book
                        break;
                        
                    case 3://Single room case
                        //Create new booking and assign room number to it
                        BookingRoom NewRoomBooking3 = new BookingRoom(id,BookingName,BookingEmail,ReservoirPhone,room_numbers,ReservationDate,ReservationTime,"Single Room",150.0);
                        RoomList.add(NewRoomBooking3);
                        while(true){
                            room_num = (int)Math.floor(Math.random()*(MAXROOMS-1+1)+1);
                            if(!rooms_reserved.contains(""+room_num+"")){
                                room_numbers+=" "+room_num+" ";
                                break;      
                            }     
                        }
                        System.out.println("***** Room Added Successfully *****");
                        aval_rooms+=1;//increament the avaliable rooms so when the hotel is full no guest can book
                        break;
                    case 4: //Break Rooms Menu
                        break;  
                    default:
                        System.out.println("!! ERROR: This Option Invalid !! ");
                        break;

                }
            }while(room_ch!=4);
            
            //Print the id for the guest to use it for other services
            Guest NewGesut = new Guest(BookingName,id,BookingEmail,ReservoirPhone);
            Guest.GuestList.add(NewGesut); 
            System.out.println();
            System.out.println("** Your Booking Was successful, Your Room Number are ("+room_numbers+") **");
            System.out.println("** Your ID is ("+id+") Please keep it with you for other services **");
           

        }
            
        else
            System.out.println("*** SORRY: All Rooms are Reserved  ***");
           
    }//END of AddBooking
    
    
    //Method to check guest phone number
    public static boolean chekcPhone(String phone){
        for (int i = 0; i < phone.length(); i++)
            if (Character.isDigit(phone.charAt(i)) == false)
                return false;
        return true;
    }
    //Method to Check Date
    public static boolean checkDate(String date){       
        String Dateregex = "^([0-2]?[0-9]|[3][01])/[0-1]?[0-2]/[2][01][2-9][2-9]$";
        Pattern Datepattern = Pattern.compile(Dateregex);
        if (date == null){
            return false;
        }
        return Datepattern.matcher(date).matches();
             
    }
    
     //Method to Check Time
    public static boolean checkTime(String time){       
        String Timeregex = "([01]?[0-9]|2[0-3]):[0-5][0-9]";
        Pattern Timepattern = Pattern.compile(Timeregex);
        if (time == null){
            return false;
        }
        return Timepattern.matcher(time).matches();
             
    }
    
    
    //Method to Check guest email
    static boolean isValid(String email){

        String emailRegex = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,6}";
        Pattern Sample = Pattern.compile(emailRegex);
        if (email == null){
            return false;
        }
        return Sample.matcher(email).matches();
 
    }

}
    
    
    




