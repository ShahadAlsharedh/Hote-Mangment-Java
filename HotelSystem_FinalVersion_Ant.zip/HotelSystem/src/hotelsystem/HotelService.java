package hotelsystem;
import static hotelsystem.Hotel.input; //Import same Scanner form the main class 
//You can import like this PackageName.ClassName.VariableName


//***HotelService Class is SuperClass of: ***
// 1- BookingRoom
// 2- KitchenServices
// 3- SpaServices
// 4- Gym
//HERE Only a subclasses calls

//START of Hotel service class
public class HotelService {
    
    //Declare Varables
    private String item;
    private double price;
    private int bookingid;
    static final String GuestMenu = "====================================\n" +
            "|   Our Services For Today:            |\n" +
            "========================================\n" +
            "| Options:                             |\n" +
            "|       1.Booking Room                 |\n" +
            "|       2.Display Booking information  |\n" +
            "|       3.Delete My information        |\n" +
            "|       4.Food and Drinks Services     |\n" +
            "|       5.Spa Services                 |\n" +
            "|       6.GYM Services                 |\n" +
            "|       7.Payment                      |\n" +
            "|       8.Back to welcome menu         |\n" +
            "=======================================\n";

    

    
    
    //CONSRUCTOR
    public HotelService(int bookingid, String item, double price){
        this.bookingid = bookingid;
        this.item = item;
        this.price = price;
    }
    
    //GETTERS:
    //GET item
    public String getItem() {
        return item;
    }
    
    //GET Price
    public double getPrice() {
        return price;
    }
    
    //GET Booking id
    public int getBookingid() {
        return bookingid;
    }
    
    //Service function
    static void Services(){
        //This Method is to display Guest's Mneu and make him/her choose until they choose Back.
        int choice;
        System.out.print("\n====================================\n"
                           +"===== Welcome To Guest System =====\n");
        do {
            System.out.print(GuestMenu);
            System.out.print("| Your Choice: ");
            choice = input.nextInt();
            switch (choice) {
                case 1://Booking a room
                    BookingRoom.AddBooking();
                    break;
                case 2: //Find booking
                    if(!Guest.GuestList.isEmpty())
                        BookingRoom.CheckBooking();
                    else
                        System.out.println("!! SORRY: There are no reservation in the System yet !! ");  
                    break;
                case 3: //delete for guest
                    if(!Guest.GuestList.isEmpty()||!BookingRoom.RoomList.isEmpty())    
                        Guest.SearchGuest();
                    else
                        System.out.println("!! SORRY: There are no reservation in the System yet !! ");  
                    break;
                case 4: //Kitchen Serices
                    if(!BookingRoom.RoomList.isEmpty())
                        KitchenService.KitchenServices();
                    else
                        System.out.println("!! SORRY: There are no reservation in the System yet !! ");
                    break;
                case 5: //Spa Services
                    if(!BookingRoom.RoomList.isEmpty())
                        SpaServices.Spa();
                    else
                        System.out.println("!! SORRY: There are no reservation in the System yet !! ");
                    break;
                 case 6: //Gym
                    if(!BookingRoom.RoomList.isEmpty())
                        GYM.gymServices();
                    else
                        System.out.println("!! SORRY: There are no reservation in the System yet !! ");
                    break; 
               case 7: //Payment
                   if(!BookingRoom.RoomList.isEmpty())
                        Payment.BillSummary();
                    else
                       System.out.println("!! SORRY: There are no reservation in the System yet !! ");
                    break;
                                 
                case 8: //Break and back to previous menu
                    break;
                default:
                    System.out.println("!! ERROR: This Option Invalid !! ");
                    break;
            }
        } while (choice !=8);
    }
    


}//END of Hotel service class   


