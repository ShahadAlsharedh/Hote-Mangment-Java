package hotelsystem;
import java.util.ArrayList;
import static hotelsystem.Hotel.input; //Import same Scanner form the main class 
//You can import like this PackageName.ClassName.VariableName

//***SpaService Class is Subclass of HotelService Class***
// 1 Main Methods:
// 1- Spa



public class SpaServices extends HotelService {//START of SpaService Class
    
    
    static ArrayList<SpaServices> SpaList = new ArrayList<>();
    static final String SpaMenu = 
                "===================================================\n" +
                "|choose a service:                               |\n" +
                "| 1.Hot stone Massage 60min.         price: 345  |\n" +
                "| 2.Relaxing Ear Candle.             price: 57   |\n" +
                "| 3.Massage 60min.                   price: 250  |\n" +
                "| 4.15min Foot Massage.              price: 50   |\n" +
                "| 5.15min Hands Massage.             price: 50   |\n" +
                "| 6.Basic Manicure and Pedicure.     price: 200  |\n" +
                "| 7.Dior Manicure and Pedicure.      price: 360  |\n" +
                "| 8.Nail Polish Hand.                price: 20   |\n" +
                "| 9.Nail Polish Foot.                price: 20   |\n" +
                "| 10.Nails Art.                      price: 60   |\n" +
                "| 11.Back to main menu.                          |\n" +
                "===================================================\n";
    
    public SpaServices(int BookindID,String item, double price) {
        super(BookindID,item, price);
    }
        
        
    public static void Spa(){
        boolean found = false;
        while(!found){
            System.out.print("| Enter Your Booking ID To Access Spa Services: ");
            int Bookid = input.nextInt();
            for(int i=0; i<BookingRoom.RoomList.size();i++){
                if(BookingRoom.RoomList.get(i).getBookingid()==Bookid){
                    found=true;         
                }

            }
            if(found){
                int ch;
                System.out.print("\n====================================\n"
                                +"==== Welcome To Spa Services ====\n");
                System.out.print(SpaMenu); 
                do{
                    System.out.print("| Choose the service you want: ");
                    ch=input.nextInt();
                    switch (ch) {
                        case 1:
                            SpaList.add(new SpaServices(Bookid,"Hot stone Massage 60min",345));
                            System.out.println("***** Service Added Successfully *****");
                            break;
                        case 2:
                            SpaList.add(new SpaServices(Bookid,"Relaxing Ear Candle",57));
                            System.out.println("***** Service Added Successfully *****");
                            break;
                        case 3:
                            SpaList.add(new SpaServices(Bookid,"Massage 60min",250));
                            System.out.println("***** Service Added Successfully *****");
                            break;
                        case 4:
                            SpaList.add(new SpaServices(Bookid,"15min Foot Massage",50));
                            System.out.println("***** Service Added Successfully *****");
                            break;
                        case 5:
                            SpaList.add(new SpaServices(Bookid,"15min Hands Massage",50));
                            System.out.println("***** Service Added Successfully *****");
                            break;
                        case 6:
                            SpaList.add(new SpaServices(Bookid,"Basic Manicure and Pedicure",200));
                            System.out.println("***** Service Added Successfully *****");
                            break;
                        case 7:
                            SpaList.add(new SpaServices(Bookid,"Dior Manicure and Pedicure",360));
                            System.out.println("***** Service Added Successfully *****");
                            break;
                        case 8:
                            SpaList.add(new SpaServices(Bookid,"Nail Polish Hand",20));
                            System.out.println("***** Service Added Successfully *****");
                            break;
                        case 9:
                            SpaList.add(new SpaServices(Bookid,"Nail Polish Foot",20));
                            System.out.println("***** Service Added Successfully *****");
                            break;
                        case 10:
                            SpaList.add(new SpaServices(Bookid,"Nail Art",60));
                            System.out.println("***** Service Added Successfully *****");
                            break;
                        case 11:
                            break;
                        default:
                            System.out.println("!! ERROR: This Option Invalid !! ");
                            break;
                    }

                }while(ch!=11);
                displaySpaServices();
            }
            else
                System.out.println("!! ERROR: No Booking Found With Provided ID !!");
        }
    }
    
    
   public static void displaySpaServices(){
       
       for(int i = 0; i< SpaList.size();i++){
            SpaServices x = SpaList.get(i);
            System.out.println("*** You choose: "+x.getItem()+", and price "+x.getPrice() +" SAR ***" );
        }
   }
    
}//START of SpaService Class
    
