package hotelsystem;
import java.util.ArrayList;
import static hotelsystem.Hotel.input; //Import same Scanner form the main class 
//You can import like this PackageName.ClassName.VariableName

public class Payment{
    

    public static int PaymentMethod;
    private boolean payed ;
    private int bookingid;
    static double SubTotal;
    static double GrandTotal;
    final static double VAT = 0.15;
    static ArrayList<Payment> PaymentList = new ArrayList<>();
    static final String PAYMENTMETHODMENU = "====================================\n" +
        "|        Choose a payment method:  |\n" +
        "|        1.Cash                    |\n" +
        "|        2.Credit Card             |\n" +
        "|        3.Back to main menu       |\n" +
        "====================================\n";
    

    public Payment(int BookingID, boolean payed) {
        this.bookingid = BookingID;
        this.payed = payed;
    }

    public boolean isPayed() {
        return payed;
    }
    
    public void setPayed(boolean payed){
        this.payed = payed;
    }
    
    
    public static void BillSummary(){
        SubTotal = 0.0;
        GrandTotal = 0.0;
        int index=0;
        int bookid =1;
        boolean found = false;
       
        do{//Do until found reservation or 0 to go back
            
            //To search for Booking 
            System.out.print("| Enter Guest ID To Pay (0 to go back): ");
            bookid = input.nextInt();
            if(bookid==0){            
                break;
            }
            for(int i=0; i < BookingRoom.RoomList.size();i++){
                if(BookingRoom.RoomList.get(i).getBookingid()==bookid){
                    found=true;
                    index = i;
                    PaymentList.add(new Payment(bookid,false));
                    break;
                }
            }

            //IF Booking Found:
            if(found){
                if(!PaymentList.get(index).isPayed()){//IF Booking Not payed
                    System.out.println();
                    System.out.println("============= Here is your bill: =============");
                    System.out.println("| Your Booking ID: "+bookid);
                    if (!BookingRoom.RoomList.isEmpty()){
                        System.out.println("*** Rooms Reserved:");
                        for(int i=0; i<BookingRoom.RoomList.size();i++){
                            if(BookingRoom.RoomList.get(i).getBookingid()==bookid){
                                System.out.println(BookingRoom.RoomList.get(i).getRoomType()+": "+BookingRoom.RoomList.get(i).getPrice());
                                double p = BookingRoom.RoomList.get(i).getPrice();
                                SubTotal+=p;
                                }
                            }
                        }
                    if(!KitchenService.DrinkList.isEmpty()){
                        System.out.println("*** Drinks Items:");
                        for(int i=0; i<KitchenService.DrinkList.size();i++){
                            if(KitchenService.DrinkList.get(i).getBookingid()==bookid){
                                System.out.println(KitchenService.DrinkList.get(i).getItem()+": "+KitchenService.DrinkList.get(i).getPrice());
                                double p = KitchenService.DrinkList.get(i).getPrice();
                                SubTotal+=p;
                            }
                        }
                    }
                    
                    if(!KitchenService.FoodList.isEmpty()){                            
                        System.out.println("*** Food Items:");
                        for(int i=0; i<KitchenService.FoodList.size();i++){
                            if(KitchenService.FoodList.get(i).getBookingid()==bookid){
                                System.out.println(KitchenService.FoodList.get(i).getItem()+": "+KitchenService.FoodList.get(i).getPrice());
                                double p = KitchenService.FoodList.get(i).getPrice();
                                SubTotal+=p;
                            }
                        }
                    }

                    if(!SpaServices.SpaList.isEmpty()){
                        System.out.println("*** Spa Services:");
                        for(int i=0; i<SpaServices.SpaList.size();i++){
                            if(SpaServices.SpaList.get(i).getBookingid()==bookid){
                                System.out.println(SpaServices.SpaList.get(i).getItem()+": "+SpaServices.SpaList.get(i).getPrice());
                                double p = SpaServices.SpaList.get(i).getPrice();
                                SubTotal+=p;
                            }
                        }
                    }
                        
                    if(!GYM.GymList.isEmpty()){                            
                        System.out.println("*** GYM Services:");
                        for(int i=0; i<GYM.GymList.size();i++){
                            if(GYM.GymList.get(i).getBookingid()==bookid){
                                System.out.println(GYM.GymList.get(i).getItem()+": "+GYM.GymList.get(i).getPrice());
                                double p = GYM.GymList.get(i).getPrice();
                                SubTotal+=p;
                            }
                        }
                    }
                        
                    System.out.println("| SubTotal: "+SubTotal);
                    System.out.println("| VAT: "+SubTotal*VAT);
                    GrandTotal = SubTotal + SubTotal*VAT;
                    System.out.println("| GrandTotal: "+GrandTotal);
                    System.out.println("\n");
                    Pay(index,GrandTotal);
                }
                else{//IF Booking is payed
                    System.out.println("!! ERROR: This Booking is Already Payed !!!");                    
                }
            
            }
            
            else //IF Booking Not Found
                System.out.println("!! ERROR: No Reservation with that ID !!!");
        }while(!found);
    }//END of BillSummary method
    
    

    public static void Pay(int index, double grand_total){
        double PayBack;
        double amount;

        do{
                        
            System.out.print("\n====================================\n"
                             +"=== How Would You Like To Pay? ===\n");
            System.out.println(PAYMENTMETHODMENU);
            System.out.print("| Your choice: ");
            PaymentMethod = input.nextInt();
            
            
            if(PaymentMethod==1){//IF user Choose Cash
                System.out.print("| Pay amount > ");
                amount = input.nextDouble();
                if (amount == grand_total){
                    System.out.println("***** Your Payment is Done Successfully *****");
                    System.out.println("***** Thank you for choosing us...Your now returning to main menu *****");
                    PaymentList.get(index).setPayed(true);
                    break;
                    }
                    else if (amount > grand_total){
                        PayBack =  amount - grand_total;
                        System.out.println("***** Your Payment is Done Successfully *****");
                        System.out.println("Here is remaining amount: " + PayBack+" SAR");
                        System.out.println("***** Thank you for choosing us...Your now returning to main menu *****");
                        PaymentList.get(index).setPayed(true);
                        break;
                    }
                    else if (amount < grand_total){
                        PayBack = grand_total - amount;
                        System.out.println("!! ERROR: Payment Failed, You Entered the Less Than The Bill Amount !!");
                        System.out.println("!! You need to pay " +  PayBack+" SAR");
                        System.out.println("!! Please Try again !!");

                    }

                }//END of Cash Case
            
                else if(PaymentMethod==2){//IF user choose cridet cart
                    //!!!For credit card case the user must enter the exact amount!!!
                    System.out.print("| Pay amount > ");
                    amount = input.nextDouble();
                    if (amount == grand_total){
                        System.out.println("***** Your Payment is Done Successfully *****");
                        System.out.println("***** Thank you for choosing us...Your now returning to main menu *****");
                        PaymentList.get(index).setPayed(true);
                        break;
                    }
                    else if (amount > grand_total){
                        System.out.println("!! ERROR: You Entered The Wrong Amount !!");
                        System.out.println("!! You need to pay " +  grand_total+" SAR");
                        System.out.println("!! Please Try again !!");
                   }
                    else if (amount < grand_total){
                        System.out.println("!! ERROR: Payment Failed, You Entered the Less Than The Bill Amount !!");
                        System.out.println("!! You need to pay " +  grand_total+" SAR");
                        System.out.println("!! Please Try again !!");
                    }

                }//END of cridet cart case
                
                
                else if(PaymentMethod==3)//IF user choose back to main menu
                    break;  
                
                else //IF user choose Wrong option
                    System.out.println("!! ERROR: This Option Invalid !! ");
        }while(PaymentMethod!=3);

    }//END of pay method
 }

