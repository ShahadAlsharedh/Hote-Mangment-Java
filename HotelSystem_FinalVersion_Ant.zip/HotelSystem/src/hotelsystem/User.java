package hotelsystem;


//***User Class is SuperClass of: ***
// 1- Admin
// 2- Guest


public class User {
    private String UserName;
    private int UserID;
    private String UserPhoneNumber;


    User(String UserName,int UserID, String UserPhoneNumber){
        this.UserName=UserName;
        this.UserID=UserID;
        this.UserPhoneNumber=UserPhoneNumber;
    }

    // GETTERS & SETTERS
    public String getUserName(){
        return UserName;
    }
    public int getUserID(){
        return UserID;
    }

    public void setUserName(String newName){
        this.UserName=newName;
    }

    public void setUserID(int newID){
        this.UserID=newID;
    }

    public String getUserPhoneNumber() {
        return UserPhoneNumber;
    }

    public void setUserPhoneNumber(String UserPhoneNumber) {
        this.UserPhoneNumber = UserPhoneNumber;
    }

    
    @Override
    public String toString(){
        return UserName+" "+UserID;
    }


}
