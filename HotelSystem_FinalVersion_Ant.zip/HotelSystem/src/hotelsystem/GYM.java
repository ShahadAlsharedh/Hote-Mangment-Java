package hotelsystem;
import java.util.ArrayList;
import static hotelsystem.Hotel.input; //Import same Scanner form the main class 
//You can import like this PackageName.ClassName.VariableName

//***GYM Class is Subclass of HotelService Class***
// 1 Main Methods:
// 1- gymServices


public class GYM extends HotelService {
    
    
    static ArrayList <GYM> GymList = new ArrayList<>();
    private static int gym_ch;
    static final String GymMenu = 
        "=============================================\n" +
        "|choose selection:                          |\n" +
        "| 1.Yoga Class.             price: 300      |\n" +
        "| 2.Pilates Class.          price: 150      |\n" +
        "| 3.Cardio Class.           price: 250      |\n" +
        "| 4.Swimming Class.         price: 150      |\n" +
        "| 5.Back to main menu.                     |\n" +
        "=============================================\n";
    
    public GYM(int bookingid, String item, double price) {
        super(bookingid, item, price);
    }
    
    public static void gymServices(){
        
        boolean found = false;
        while(!found){
            System.out.print("| Enter Your Booking ID To Access GYM Services: ");
                int Bookid = input.nextInt();

                for(int i=0; i<BookingRoom.RoomList.size();i++){
                    if(BookingRoom.RoomList.get(i).getBookingid()==Bookid){
                        found=true;         
                    }

                }
                if(found){
                    System.out.print("\n====================================\n"
                                        +"==== Welcome To GYM Services ====\n");
                    System.out.print(GymMenu); 
                    do{
                        System.out.print("| Choose the service you want: ");
                        gym_ch=input.nextInt();
                        switch (gym_ch) {
                            case 1:
                                GymList.add(new GYM(Bookid,"Yoga Class",300));
                                System.out.println("***** Service Added Successfully *****");
                                break;
                            case 2:
                                GymList.add(new GYM(Bookid,"Pilates Class",150));
                                System.out.println("***** Service Added Successfully *****");
                                break;
                            case 3:
                                GymList.add(new GYM(Bookid,"Cardio Class",250));
                                System.out.println("***** Service Added Successfully *****");
                                break;
                            case 4:
                                GymList.add(new GYM(Bookid,"Swimming Class",150));
                                System.out.println("***** Service Added Successfully *****");
                                break;
                            case 5:
                                break;
                            default:
                                System.out.println("!! ERROR: This Option Invalid !! ");
                                break;
                        }

                    }while(gym_ch!=5);
                }
                else
                    System.out.println("!! ERROR: No Booking Found With Provided ID !!");

                displayGymServices();

        }
    
    }    
   public static void displayGymServices(){
       
       for(int i = 0; i< GymList.size();i++){
            GYM x = GymList.get(i);
            System.out.println("*** You choose: "+x.getItem()+", and price "+x.getPrice() +" SAR ***" );
        }
   }

    
}


