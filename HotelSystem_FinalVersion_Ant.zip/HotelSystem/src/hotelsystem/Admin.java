package hotelsystem;
import static hotelsystem.Hotel.input; //Import same Scanner form the main class 
//You can import like this PackageName.ClassName.VariableName
import java.util.ArrayList;


//***Admin Class is Subclass of User Class***
// 4 Main Methods:
// 1- Add New Admin
// 2- Remove Existing Admin
// 3- Update Existing Admin
// 4- Display Admins in System


public class Admin extends User {

    //Declare Variables
    private  double Salary; //Admin's Salary
    private  int WorkingHours; //Admin's Working hours
    private String Password; //Admin's Password
    static ArrayList <Admin> AdminList = new ArrayList<>(); //Admin ArrayList to save all Admins in system
    static final String AdminUpdate = "====================================\n" + //Admin Update Menu
            "|   Choose Field to Update        |\n" +
            "====================================\n" +
            "| Options:                         |\n" +
            "|       1.Admin Name               |\n" +
            "|       2.Admin ID                 |\n" +
            "|       3.Admin Password           |\n" +
            "|       4.Admin Phone Number       |\n" +
            "|       5.Admin Salary             |\n" +
            "|       6.Admin Working Hours      |\n" +
            "|       7.Back To Main Menu        |\n" +
            "====================================\n";
    static final String AdminMenu=
            "| AdminMenu                            |\n"+ //Admin Main Menu
            "========================================\n"+
            "| Options:                             |\n"+
            "|        1-Add New Admin               |\n"+
            "|        2-Remove Admin                |\n"+
            "|        3-Update Admins Information   |\n"+
            "|        4-Display Admins Information  |\n"+
            "|        5-Exit from Admin System      |\n"+
            "========================================\n";
    

// CONSTRUCTORS
    public Admin(String UserName, int UserID,String AdminPhoneNumber){
        super(UserName, UserID,AdminPhoneNumber); //Called User Class Constructor
    }

    public Admin(String UserName, int UserID, String Password, String PhoneNum, double Salary, int WorkingHours) {
        super(UserName, UserID,PhoneNum); //Called User Class Constructor
        this.Salary = Salary;
        this.WorkingHours = WorkingHours;
        this.Password = Password;
    }

    // GETTERS
    
    //GET Admin password
    public String getPassword(){
        return Password;
    }
    
    //GET Admin Salary
    public double  getSalary(){
        return Salary;
    }
    
    //GET Admin Working hours
    public int  getWorkingHours(){
        return WorkingHours;
    }

    //SETTERS
   

    //SET Admin's Salary
    public void setSalary(double Salary) {
        this.Salary = Salary;
    }

    //SET Admin's Workin hours
    public void setWorkingHours(int WorkingHours) {
        this.WorkingHours = WorkingHours;
    }

    //SET Admin's password
    public void setPassword(String Password) {
        this.Password = Password;
    }

    
    // METHODS
    
    //Switch Admin Choice Method
    public static void AdminSwitchChoice(){//START of AdminSwitchChoice
        //This Method is to display Admin's Mneu and make him/her choose until they choose Back.
        int admin_ch;
        System.out.print("\n====================================\n"
                            +"===== Welcome To Admin System =====\n");
        
        do{//Do until Admin enters 5
            System.out.print(Admin.AdminMenu ); //Print Admin Main menu
            System.out.print("Your choice: " );
            admin_ch = input.nextInt(); //Take Admin Choice
            switch (admin_ch){
                case 1: //add admin info
                    addAdminInfo();
                    break;
                case 2://remove Admin
                    removeAdmin();
                    break;
                case 3: //Update Admin informations
                    UpdateAdminInfo();
                    break;
                case 4: //print Admin info 
                    printAdmin();
                    break;
                case 5:
                    break;
                default:
                    System.out.println("!! ERROR: This Option Invalid !! ");
                    break;
            }//END of Admin Switch
            
        }while(admin_ch!=5);
    }//END of AdminSwitchChoice
    
    
    //Add New Admin Method
    public static void addAdminInfo(){ //START of addAdminInfo
        //The idea is to make admin enter a valid information and then add that information to the AdminList
        String ans;
        do{//Do until Admin enters N
            System.out.println("============= New Admin =============");
            System.out.println("==== Please Enter New Admin information ====");
            
            //Take Admin Name
            System.out.print("| Enter Admin  Name: ");
            String AdminName = input.next();

            //Take Admin ID (Must be Not Exist in the System)
            System.out.print("| Enter Admin  ID: ");
            int AdminID = input.nextInt();
            while(!checkID(AdminID)){
                System.out.println("!! ERROR: This ID is exist, Please Enter New One !!");
                System.out.print("| Please enter again: ");
                AdminID = input.nextInt();
            }
            
            //Take Admin Password
            System.out.print("| Enter Admin Password: ");
            String AdminPassword = input.next();

            //Take Admin phone number (Must be 10 digit and start with 05)
            System.out.print("| Enter Admin Phone Number: ");
            String AdminPhoneNum = input.next();         
            while(!BookingRoom.chekcPhone(AdminPhoneNum)|| AdminPhoneNum.length() != 10 || !(AdminPhoneNum.startsWith("05"))){
                System.out.println("!! ERROR: This Phone number Invalid !!");
                System.out.print("| Please enter again: ");
                AdminPhoneNum = input.next();
            }
            
            //Take Admin Salary (Must be non nigative and not 0)
            System.out.print("| Enter Admin Salary: ");
            double AdminSalary = input.nextDouble();
            while(Check(AdminSalary)){
                System.out.println("!! ERROR: Salary is Invalid !!");
                System.out.print("| Please Enter Again: ");
                AdminSalary = input.nextDouble();
            }
            
            //Take Admin Hours (Must be non nigative and not 0)
            System.out.print("| Enter Admin WorkingHours: ");
            int AdminWorkingHours = input.nextInt(); 
            while(Check(AdminWorkingHours) || AdminWorkingHours > 24 ){
                System.out.println("!! ERROR: Workin hours is Invalid !!");
                System.out.print("| Please Enter Again: ");
                AdminWorkingHours = input.nextInt();
            }

            //Creat New Admin
            Admin NewAdmin = new Admin(AdminName ,AdminID, AdminPassword, AdminPhoneNum, AdminSalary, AdminWorkingHours);
            AdminList.add(NewAdmin);

            System.out.println();
            System.out.println(NewAdmin.toString()+"\n");
            
            //If the Admin wants to add new admin
            System.out.print("Do You Want to Add Another Admin (Y/N)? ");
            ans = input.next();

        }while(ans.equalsIgnoreCase("Y"));
        
        if(ans.equalsIgnoreCase("N")){
            System.out.println("***** Admin Information Added Successfully *****");
        }
        else{
            System.out.println("!! ERROR: This Option Invalid !! ");
        }
    } //END of addAdminInfo 

    
    
    //remove Admin Method
    public static void removeAdmin(){//START of removeAdmin
        //The idea is to make admin enter a valid id and then remove that id from the AdminList
        boolean found = false;
        int adminid;
        
        while(!found){//Keep looping until found
            if(!AdminList.isEmpty()){
            
                System.out.print("| Enter Admin ID to remove (0 to go back): ");
                adminid = input.nextInt();
                if(adminid==0){
                        break;   
                }
                if (!AdminList.isEmpty()){
                    for(int i = 0; i < AdminList.size();i++){
                        if (AdminList.get(i).getUserID() == adminid){
                            found =true;
                            AdminList.remove(AdminList.get(i));
                            System.out.println("***** Admin Information Removed Successfully *****");

                        }

                    }

                }
                if (!found){
                        System.out.println("!! ERROR: No Admin Found With Provided ID !!");
                }
            }
            else
                System.out.println("!! ERROR: No Admin In System Yet !!");
        }
    }//END of removeAdmin
    
    
    
    public static void UpdateAdminInfo(){//START of UpdateAdminInfo
        //The idea is to make the admin choose a field to update
        //if he choose for example 1 he can update admin name...and so on for the rest
        boolean found = false;
        int UpdateID;
        System.out.println(AdminUpdate);
        while(!found){ //Repeat untill user enter valid id  
            printAdmin();
            System.out.print("| Enter Admin ID (0 to go back): ");
            UpdateID = input.nextInt();
            if(UpdateID==0){
                    break;   
            }
            int index=0;
            for(int i=0; i< AdminList.size();i++){
                if(AdminList.get(i).getUserID()==UpdateID){
                    found = true;
                    index = i;
                    break;
                }     
            }
            if(found){
                int a_choice = 0;
                do{
                    System.out.print("| Your choice: " );
                    a_choice = input.nextInt();
                    switch(a_choice){
                        case 1:
                            System.out.print("| Enter New Name: ");
                            String newName = input.next();
                            AdminList.get(index).setUserName(newName);
                            System.out.println("***** Admin Information Updated Successfully *****");
                            break;
                        case 2:
                            System.out.print("| Enter New ID: ");
                            int newID = input.nextInt();
                            while(!checkID(newID)){
                                System.out.println("!! ERROR: This ID is exist, Please Enter New One !!");
                                System.out.print("| Please enter again: ");
                                newID = input.nextInt();
                            }
                            AdminList.get(index).setUserID(newID);
                            System.out.println("***** Admin Information Updated Successfully *****");
                            break;
                        case 3:
                            System.out.print("| Enter New Password: ");
                            String newPassword = input.next();
                            AdminList.get(index).setPassword(newPassword);
                            System.out.println("***** Admin Information Updated Successfully *****");
                            break;
                        case 4:
                            System.out.print("| Enter New Phone Number: ");
                            String newPhone= input.next();
                            while(!BookingRoom.chekcPhone(newPhone)|| newPhone.length() != 10 || !(newPhone.startsWith("05"))){
                            System.out.println("!! ERROR: This Phone number Invalid !!");
                                System.out.print("| Please enter again: ");
                                newPhone = input.next();
                            }
                            AdminList.get(index).setUserPhoneNumber(newPhone);
                            System.out.println("***** Admin Information Updated Successfully *****");
                            break;
                        case 5:
                            System.out.print("| Enter Salary: ");
                            double newSalary= input.nextDouble();
                            while(Check(newSalary)){
                                System.out.println("!! ERROR: Salary is Invalid !!");
                                System.out.print("| Please Enter Again: ");
                                newSalary = input.nextDouble();
                            }
                            AdminList.get(index).setSalary(newSalary);
                            System.out.println("***** Admin Information Updated Successfully *****");
                            break;
                        case 6:
                            System.out.print("| Enter New Working Hours: ");
                            int newHours= input.nextInt();
                            while(Check(newHours)){
                                System.out.println("!! ERROR: Working Hours is Invalid !!");
                                System.out.print("| Please Enter Again: ");
                                newHours = input.nextInt();
                            }
                            AdminList.get(index).setWorkingHours(newHours);
                            System.out.println("***** Admin Information Updated Successfully *****");
                            break;
                        case 7:
                            break;
                        default:
                            System.out.println("!! ERROR: This Option Invalid !! ");
                            break;


                    }
                }while(a_choice!=7);
            }
            else
                System.out.println("!! ERROR: No Admin Found With Provided ID !!");


        }
    }
    
    
    public static void printAdmin(){
        System.out.println("=========     Admins     ==========");
        for(int i = 0;i < AdminList.size();i++){
            System.out.println(" Admin User Name: "+ AdminList.get(i).getUserName());
            System.out.println(" Admins ID: "+ AdminList.get(i).getUserID());
            System.out.println(" Admins Password: "+AdminList.get(i).getPassword());
            System.out.println(" Admins Phone No: "+AdminList.get(i).getUserPhoneNumber());
            System.out.println(" Admins Salary: "+AdminList.get(i).getSalary() +" SAR");
            System.out.println(" Admins WorkingHours: "+AdminList.get(i).getWorkingHours());
            System.out.println("====================================");
        }
    }

    //Check Salary Method
    public static boolean Check(double Salary){
        return (Salary <= 0);
    }
    
    //@Overload
    //Check Hours Method
    public static boolean Check(int hours){
        return (hours <= 0);
    }
    //Check ID Mthod
    public static boolean checkID(int ID){
        for(int i=0 ; i< AdminList.size(); i++){
            if(AdminList.get(i).getUserID() == ID){
                return false;
            }
        
        }
       return true;    
    }
    
    //To String override method
    @Override
    public String toString(){
        return "***** Total Admins in the system: "+AdminList.size()+" *****";
    }
    
    
}
